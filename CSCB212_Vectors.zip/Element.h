#ifndef _ELEMENT_H
#define _ELEMENT_H
#include "stdafx.h"
#include <iostream>

using namespace std;

class Element {
	virtual int print() const = 0;
};

#pragma once

#endif // !_ELEMENT_H
